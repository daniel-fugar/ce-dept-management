--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: get_outstanding_fees(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_outstanding_fees() RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
    result JSON;
BEGIN
    SELECT json_agg(t)
    INTO result
    FROM (
        SELECT 
            s.student_id,
            CONCAT(s.first_name, ' ', s.last_name) AS student_name,
            f.amount_due,
            COALESCE(SUM(p.amount_paid), 0) AS total_paid,
            f.amount_due - COALESCE(SUM(p.amount_paid), 0) AS balance
        FROM students s
        JOIN fee_structure f ON s.year_of_study = f.year_of_study
        LEFT JOIN fees p ON s.student_id = p.student_id
        GROUP BY s.student_id, student_name, f.amount_due
    ) t;

    RETURN result;
END;
$$;


ALTER FUNCTION public.get_outstanding_fees() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: course_enrollment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.course_enrollment (
    enrollment_id integer NOT NULL,
    student_id integer,
    course_id integer
);


ALTER TABLE public.course_enrollment OWNER TO postgres;

--
-- Name: course_enrollment_enrollment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.course_enrollment_enrollment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.course_enrollment_enrollment_id_seq OWNER TO postgres;

--
-- Name: course_enrollment_enrollment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.course_enrollment_enrollment_id_seq OWNED BY public.course_enrollment.enrollment_id;


--
-- Name: courses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.courses (
    course_id integer NOT NULL,
    course_code character varying(20),
    course_name character varying(100),
    credit_hours integer
);


ALTER TABLE public.courses OWNER TO postgres;

--
-- Name: courses_course_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.courses_course_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.courses_course_id_seq OWNER TO postgres;

--
-- Name: courses_course_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.courses_course_id_seq OWNED BY public.courses.course_id;


--
-- Name: fee_structure; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fee_structure (
    year_of_study integer NOT NULL,
    amount_due numeric(10,2)
);


ALTER TABLE public.fee_structure OWNER TO postgres;

--
-- Name: fees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fees (
    payment_id integer NOT NULL,
    student_id integer,
    amount_paid numeric(10,2),
    payment_date date DEFAULT CURRENT_DATE
);


ALTER TABLE public.fees OWNER TO postgres;

--
-- Name: fees_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fees_payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fees_payment_id_seq OWNER TO postgres;

--
-- Name: fees_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fees_payment_id_seq OWNED BY public.fees.payment_id;


--
-- Name: lecturer_course; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lecturer_course (
    lecturer_id integer NOT NULL,
    course_id integer NOT NULL
);


ALTER TABLE public.lecturer_course OWNER TO postgres;

--
-- Name: lecturer_ta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lecturer_ta (
    lecturer_id integer NOT NULL,
    ta_id integer NOT NULL
);


ALTER TABLE public.lecturer_ta OWNER TO postgres;

--
-- Name: lecturers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lecturers (
    lecturer_id integer NOT NULL,
    name character varying(100),
    email character varying(100)
);


ALTER TABLE public.lecturers OWNER TO postgres;

--
-- Name: lecturers_lecturer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lecturers_lecturer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lecturers_lecturer_id_seq OWNER TO postgres;

--
-- Name: lecturers_lecturer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lecturers_lecturer_id_seq OWNED BY public.lecturers.lecturer_id;


--
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    student_id integer NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    email character varying(100),
    year_of_study integer
);


ALTER TABLE public.students OWNER TO postgres;

--
-- Name: students_student_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.students_student_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.students_student_id_seq OWNER TO postgres;

--
-- Name: students_student_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.students_student_id_seq OWNED BY public.students.student_id;


--
-- Name: tas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tas (
    ta_id integer NOT NULL,
    name character varying(100),
    email character varying(100)
);


ALTER TABLE public.tas OWNER TO postgres;

--
-- Name: tas_ta_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tas_ta_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tas_ta_id_seq OWNER TO postgres;

--
-- Name: tas_ta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tas_ta_id_seq OWNED BY public.tas.ta_id;


--
-- Name: course_enrollment enrollment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_enrollment ALTER COLUMN enrollment_id SET DEFAULT nextval('public.course_enrollment_enrollment_id_seq'::regclass);


--
-- Name: courses course_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses ALTER COLUMN course_id SET DEFAULT nextval('public.courses_course_id_seq'::regclass);


--
-- Name: fees payment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fees ALTER COLUMN payment_id SET DEFAULT nextval('public.fees_payment_id_seq'::regclass);


--
-- Name: lecturers lecturer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lecturers ALTER COLUMN lecturer_id SET DEFAULT nextval('public.lecturers_lecturer_id_seq'::regclass);


--
-- Name: students student_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students ALTER COLUMN student_id SET DEFAULT nextval('public.students_student_id_seq'::regclass);


--
-- Name: tas ta_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tas ALTER COLUMN ta_id SET DEFAULT nextval('public.tas_ta_id_seq'::regclass);


--
-- Data for Name: course_enrollment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.course_enrollment (enrollment_id, student_id, course_id) FROM stdin;
1	1	1
2	1	2
3	1	3
4	2	1
5	2	2
6	2	3
7	3	1
8	3	3
9	4	1
10	4	2
11	5	2
12	5	3
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.courses (course_id, course_code, course_name, credit_hours) FROM stdin;
1	CPEN208	Intro to Software Engineering	3
2	CPEN210	Computer Architecture	3
3	CPEN212	Data Structures	3
\.


--
-- Data for Name: fee_structure; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fee_structure (year_of_study, amount_due) FROM stdin;
2	1500.00
\.


--
-- Data for Name: fees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fees (payment_id, student_id, amount_paid, payment_date) FROM stdin;
1	1	1500.00	2025-06-23
2	2	1000.00	2025-06-23
3	3	1500.00	2025-06-23
4	4	500.00	2025-06-23
5	5	0.00	2025-06-23
\.


--
-- Data for Name: lecturer_course; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lecturer_course (lecturer_id, course_id) FROM stdin;
1	1
2	2
2	3
\.


--
-- Data for Name: lecturer_ta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lecturer_ta (lecturer_id, ta_id) FROM stdin;
1	1
2	2
\.


--
-- Data for Name: lecturers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lecturers (lecturer_id, name, email) FROM stdin;
1	Dr. Kwame Mensah	kmensah@ug.edu.gh
2	Dr. Akua Owusu	aowusu@ug.edu.gh
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (student_id, first_name, last_name, email, year_of_study) FROM stdin;
1	Daniel Delawoe	Fugar	dfugar@ug.edu.gh	2
2	Jessica Yorm	Amemor	jamemor@ug.edu.gh	2
3	Agnes-Katherine	Aboagye	aaboagye@ug.edu.gh	2
4	Jeffrey Somuah	Sarpong	jsarpong@ug.edu.gh	2
5	Elvis Kwason	Tiburu	etiburu@ug.edu.gh	2
\.


--
-- Data for Name: tas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tas (ta_id, name, email) FROM stdin;
1	Linda Ofori	lofori@ug.edu.gh
2	Samuel Boateng	sboateng@ug.edu.gh
\.


--
-- Name: course_enrollment_enrollment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.course_enrollment_enrollment_id_seq', 12, true);


--
-- Name: courses_course_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.courses_course_id_seq', 3, true);


--
-- Name: fees_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fees_payment_id_seq', 5, true);


--
-- Name: lecturers_lecturer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lecturers_lecturer_id_seq', 2, true);


--
-- Name: students_student_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.students_student_id_seq', 5, true);


--
-- Name: tas_ta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tas_ta_id_seq', 2, true);


--
-- Name: course_enrollment course_enrollment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_enrollment
    ADD CONSTRAINT course_enrollment_pkey PRIMARY KEY (enrollment_id);


--
-- Name: courses courses_course_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_course_code_key UNIQUE (course_code);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (course_id);


--
-- Name: fee_structure fee_structure_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fee_structure
    ADD CONSTRAINT fee_structure_pkey PRIMARY KEY (year_of_study);


--
-- Name: fees fees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fees
    ADD CONSTRAINT fees_pkey PRIMARY KEY (payment_id);


--
-- Name: lecturer_course lecturer_course_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lecturer_course
    ADD CONSTRAINT lecturer_course_pkey PRIMARY KEY (lecturer_id, course_id);


--
-- Name: lecturer_ta lecturer_ta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lecturer_ta
    ADD CONSTRAINT lecturer_ta_pkey PRIMARY KEY (lecturer_id, ta_id);


--
-- Name: lecturers lecturers_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lecturers
    ADD CONSTRAINT lecturers_email_key UNIQUE (email);


--
-- Name: lecturers lecturers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lecturers
    ADD CONSTRAINT lecturers_pkey PRIMARY KEY (lecturer_id);


--
-- Name: students students_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_email_key UNIQUE (email);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (student_id);


--
-- Name: tas tas_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tas
    ADD CONSTRAINT tas_email_key UNIQUE (email);


--
-- Name: tas tas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tas
    ADD CONSTRAINT tas_pkey PRIMARY KEY (ta_id);


--
-- Name: course_enrollment course_enrollment_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_enrollment
    ADD CONSTRAINT course_enrollment_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(course_id);


--
-- Name: course_enrollment course_enrollment_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_enrollment
    ADD CONSTRAINT course_enrollment_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(student_id);


--
-- Name: fees fees_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fees
    ADD CONSTRAINT fees_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(student_id);


--
-- Name: lecturer_course lecturer_course_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lecturer_course
    ADD CONSTRAINT lecturer_course_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(course_id);


--
-- Name: lecturer_course lecturer_course_lecturer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lecturer_course
    ADD CONSTRAINT lecturer_course_lecturer_id_fkey FOREIGN KEY (lecturer_id) REFERENCES public.lecturers(lecturer_id);


--
-- Name: lecturer_ta lecturer_ta_lecturer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lecturer_ta
    ADD CONSTRAINT lecturer_ta_lecturer_id_fkey FOREIGN KEY (lecturer_id) REFERENCES public.lecturers(lecturer_id);


--
-- Name: lecturer_ta lecturer_ta_ta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lecturer_ta
    ADD CONSTRAINT lecturer_ta_ta_id_fkey FOREIGN KEY (ta_id) REFERENCES public.tas(ta_id);


--
-- PostgreSQL database dump complete
--

